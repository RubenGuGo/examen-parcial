package es.cic.curso.ejerc1;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MuebleTest 
{

    private Mueble cut;

    @BeforeEach
    public void setup(){
        cut = new Mueble();
    }
    //
    @Test
    public void testInterface(){
        assertFalse(cut.getClass().isInstance(ConPuertas.class));
    }
    @Test
    public void testArmario(){
    }
    @Test
    public void testCama(){
        assertTrue(cut.getClass().isInstance(ConPuertas.class));
    }
}
