package es.cic.curso.ejerc1;

public interface ConPuertas {

	
	
}
