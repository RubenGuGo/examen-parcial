package es.cic.curso.ejerc1;

public class Coche implements ConPuertas{

}
