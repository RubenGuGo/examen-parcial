package es.cic.curso.ejerc1;

public class Armario extends Mueble implements ConPuertas{

	private int numCajones;
}
