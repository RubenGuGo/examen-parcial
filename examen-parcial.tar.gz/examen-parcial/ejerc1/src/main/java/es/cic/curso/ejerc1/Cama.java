package es.cic.curso.ejerc1;

public class Cama extends Mueble{

	private String sabanas;
	private boolean echa;
	
}
