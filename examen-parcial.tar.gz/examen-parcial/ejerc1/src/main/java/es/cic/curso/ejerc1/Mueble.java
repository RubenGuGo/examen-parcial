package es.cic.curso.ejerc1;

public class Mueble {

	protected int patas;
	protected String material;
}
