package es.cic.curso.ejerc4;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import es.cic.curso.ejerc4.model.Pelicula;
import es.cic.curso.ejerc4.service.PerliculaService;

@SpringBootTest
@AutoConfigureMockMvc
class PeliculIntegrationTests {

	@Autowired
	private PerliculaService perliculaService;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private MockMvc mvc;

	private Pelicula testPelicula;

	@BeforeEach
	public void BeforeEach(){
		//Ojala tener tiempo
		testPelicula = new Pelicula("TesPelicula",2000,null);
		perliculaService.crear(testPelicula);
		testPelicula = new Pelicula("TesPeliculaLaVenganza",2002,null);
		perliculaService.crear(testPelicula);
		testPelicula = new Pelicula("TestPeliculaElectricBoongaloo",1998,null);
		perliculaService.crear(testPelicula);
	}

	@Test
	void testListar() throws Exception {
		 mvc.perform(get("/api/pelicula")
		.contentType(MediaType.APPLICATION_JSON))
		.andDo(print())
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.length()").value(Matchers.greaterThanOrEqualTo(1))); 
	}

	@Test
	void testLeer() throws Exception {
		String nombre = "TesPeliculaLaVenganza";
		mvc.perform(
			get("/api/pelicula/{id}",nombre)
				.contentType(MediaType.APPLICATION_JSON))
			.andDo(print())
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.titulo").value(nombre))
			.andReturn();
	}


	@Test
	void testBorrar() throws Exception {
		mvc.perform(delete("/api/pelicula/{id}","TesPelicula")
		.contentType(MediaType.APPLICATION_JSON))
		.andDo(print())
		.andExpect(status().isOk());
		
	}

	@Test
	void testCrear() throws Exception {
		Pelicula pelicula = new Pelicula("nombre",1999,null);

		String mensaje = objectMapper.writeValueAsString(pelicula);
		mvc.perform(
			post("/api/pelicula")
				.contentType(MediaType.APPLICATION_JSON).content(mensaje))
				.andDo(print())
			.andExpect(status().isCreated())
			.andExpect(content().string("true")) 
			.andReturn();
	}
	@Test
	void testActualizar() throws Exception {
		Pelicula pelicula = new Pelicula("TestPeliculaElectricBoongaloo");

		String mensaje = objectMapper.writeValueAsString(pelicula);

		mvc.perform(
			put("/api/pelicula")
				.contentType(MediaType.APPLICATION_JSON).content(mensaje))
				.andDo(print())
			.andExpect(status().isOk());
	}
}
