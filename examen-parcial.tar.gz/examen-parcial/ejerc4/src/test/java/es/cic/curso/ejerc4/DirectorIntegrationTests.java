package es.cic.curso.ejerc4;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import es.cic.curso.ejerc4.model.Director;
import es.cic.curso.ejerc4.service.DirectorService;

@SpringBootTest
@AutoConfigureMockMvc
class DirectorIntegrationTests {

	@Autowired
	private DirectorService directorService;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private MockMvc mvc;

	private Director director;

	@BeforeEach
	public void BeforeEach(){
		//Ojala tener tiempo
		director = new Director("TestDirectorListar",2000,null);
		directorService.crear(director);
		director = new Director("TestDirectorBorrar",2002,null);
		directorService.crear(director);
		director = new Director("TestDirectorActualizar",1998,null);
		directorService.crear(director);
	}

	@Test
	void testListar() throws Exception {
		 mvc.perform(get("/api/director")
		.contentType(MediaType.APPLICATION_JSON))
		.andDo(print())
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.length()").value(Matchers.greaterThanOrEqualTo(1))); 
	}

	@Test
	void testLeer() throws Exception {
		String nombre = "TestDirectorListar";
		mvc.perform(
			get("/api/director/{id}",nombre)
				.contentType(MediaType.APPLICATION_JSON))
			.andDo(print())
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.nombre").value(nombre))
			.andReturn();
	}


	@Test
	void testBorrar() throws Exception {
		mvc.perform(delete("/api/director/{id}","TestDirectorBorrar")
		.contentType(MediaType.APPLICATION_JSON))
		.andDo(print())
		.andExpect(status().isOk());
		
	}

	@Test
	void testCrear() throws Exception {
		Director director = new Director("nombre",1999,null);

		String mensaje = objectMapper.writeValueAsString(director);
		mvc.perform(
			post("/api/director")
				.contentType(MediaType.APPLICATION_JSON).content(mensaje))
				.andDo(print())
			.andExpect(status().isCreated())
			.andExpect(content().string("true")) 
			.andReturn();
	}
	@Test
	void testActualizar() throws Exception {
		Director director = new Director("TestDirectorActualizar");

		String mensaje = objectMapper.writeValueAsString(director);

		mvc.perform(
			put("/api/director")
				.contentType(MediaType.APPLICATION_JSON).content(mensaje))
				.andDo(print())
			.andExpect(status().isOk());
	}
}
