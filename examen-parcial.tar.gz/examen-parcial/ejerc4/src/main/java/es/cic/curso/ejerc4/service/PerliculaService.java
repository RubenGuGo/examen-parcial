package es.cic.curso.ejerc4.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import es.cic.curso.ejerc4.model.Pelicula;

@Service
public class PerliculaService {
    //"El repositorio"
    private List<Pelicula> repo = new ArrayList<>();

    public List<Pelicula>listar(){
        //probar si esta devolviendo la misma ref de memoria si si cambiar
        List<Pelicula> res = repo;
        return res;
    }

    public Boolean crear(Pelicula pelicula){
        return repo.add(pelicula);
    }

    public Pelicula leer(String titulo){    
        for (Pelicula peli : repo) {
            if (peli.equals(new Pelicula(titulo))) {
                return peli;
            }
        }
        return null;
    }

    public void actualizar(Pelicula pelicula){
        int indexOf = findPelicula(pelicula);
        Pelicula peliculaAct = repo.get(indexOf);
        repo.remove(indexOf);
        peliculaAct = pelicula;
        repo.add(peliculaAct);
   }
   
   public void borrar(Pelicula pelicula){
       repo.remove(findPelicula(pelicula));
   
   }

   private int findPelicula(Pelicula pelicula){
    return repo.indexOf(pelicula);
   }
}
