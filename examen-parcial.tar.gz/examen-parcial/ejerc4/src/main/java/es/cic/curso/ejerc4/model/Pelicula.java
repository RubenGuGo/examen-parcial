package es.cic.curso.ejerc4.model;


public class Pelicula {

	    private String titulo;

	    private int anio;

	    private Director director;

		

		public Pelicula() {
		}

		public Pelicula(String titulo) {
			this.titulo = titulo;
		}

		public Pelicula(String titulo, int anio, Director director) {
			this.titulo = titulo;
			this.anio = anio;
			this.director = director;
		}

		public String getTitulo() {
			return titulo;
		}

		public void setTitulo(String titulo) {
			this.titulo = titulo;
		}

		public int getAnio() {
			return anio;
		}

		public void setAnio(int anio) {
			this.anio = anio;
		}

		public Director getDirector() {
			return director;
		}

		public void setDirector(Director director) {
			director.getPerliculas().add(this);
			this.director = director;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((titulo == null) ? 0 : titulo.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Pelicula other = (Pelicula) obj;
			if (titulo == null) {
				if (other.titulo != null)
					return false;
			} else if (!titulo.equals(other.titulo))
				return false;
			return true;
		}

	

}
