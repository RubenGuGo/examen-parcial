package es.cic.curso.ejerc4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import es.cic.curso.ejerc4.model.Pelicula;
import es.cic.curso.ejerc4.service.PerliculaService;

@RestController
@RequestMapping("api/pelicula")
public class PeliculaController {

    @Autowired
    private PerliculaService perliculaService;

    @GetMapping("/{nombre}")
    public Pelicula leer(@PathVariable("nombre") String nombre) {
        return perliculaService.leer(nombre);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Boolean crear(@RequestBody Pelicula pelicula){
    return perliculaService.crear(pelicula);
    }

    @GetMapping
public List<Pelicula> listar(){
    List<Pelicula> respuesta = perliculaService.listar();
    return respuesta;

}

@PutMapping
public void actualiza(@RequestBody Pelicula pelicula){
    perliculaService.actualizar(pelicula);
}

@DeleteMapping("/{id}")
public void borrar(@PathVariable String id){
    perliculaService.borrar(new Pelicula(id));
}



}
