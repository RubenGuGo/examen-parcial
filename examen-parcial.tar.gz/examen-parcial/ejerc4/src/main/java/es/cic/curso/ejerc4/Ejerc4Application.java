package es.cic.curso.ejerc4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejerc4Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejerc4Application.class, args);
	}

}
