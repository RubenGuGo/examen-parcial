package es.cic.curso.ejerc4.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import es.cic.curso.ejerc4.model.Director;

@Service
public class DirectorService {
    //"El repositorio"
    private List<Director> repo = new ArrayList<>();

    public List<Director>listar(){
        //probar si esta devolviendo la misma ref de memoria si si cambiar
        List<Director> res = repo;
        return res;
    }

    public Boolean crear(Director director){
        return repo.add(director);
    }

    public Director leer(Director nombre){    
        for (Director director : repo) {
            if (director.equals(nombre)) {
                return director;
            }
        }
        return null;
    }

    public void actualizar(Director director){
        int indexOf = findDirector(director);
        Director directorAct = repo.get(indexOf);
        repo.remove(indexOf);
        directorAct = director;
        repo.add(directorAct);
   }
   
   public void borrar(Director director){
       repo.remove(findDirector(director));
   
   }

   private int findDirector(Director director){
    return repo.indexOf(director);
   }


}
